import 'package:flutter/material.dart';
import 'package:skolar/core/constant/color.dart';
import 'package:skolar/core/functions/responsive.dart';

class CustomSectionCard extends StatefulWidget {
  final IconData? icon;
  final String title;
  final void Function()? onTap;

  const CustomSectionCard({
    super.key,
    this.icon,
    required this.title,
    this.onTap,
  });

  @override
  State<CustomSectionCard> createState() => _CustomSectionCardState();
}

class _CustomSectionCardState extends State<CustomSectionCard> {
  bool isHover = false;

  @override
  Widget build(BuildContext context) {
    final Responsive r = Responsive(context);

    return MouseRegion(
      onEnter: (_) => setState(() => isHover = true),
      onExit: (_) => setState(() => isHover = false),
      child: AnimatedContainer(
        duration: Duration(milliseconds: 200),
        transform: Matrix4.identity()..scale(isHover ? 1.05 : 1.0),
        decoration: BoxDecoration(
          color: AppColor.primaryColor,
          borderRadius: BorderRadius.circular(16),
          boxShadow: isHover
              ? [
                  BoxShadow(
                    blurRadius: 15,
                    offset: Offset(0, 6),
                    color: Colors.black26,
                  ),
                ]
              : [],
        ),
        child: InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap: widget.onTap,
          child: Container(
            padding: EdgeInsets.all(14),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(widget.icon, color: AppColor.textcolor, size: r.icon(50)),
                SizedBox(height: 10),
                Text(
                  widget.title,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: AppColor.textcolor,
                    fontSize: r.font(18),
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
