import 'package:flutter/material.dart';
import 'package:skolar/core/constant/color.dart';

class CustomTimeButton extends StatelessWidget {
  final String title; // اسم الزر (مثلاً "بداية الدرس" أو "نهاية الدرس")
  final TimeOfDay selectedTime; // الوقت الحالي المختار
  final void Function(TimeOfDay)
  onTimeSelected; // دالة التحديث عند اختيار وقت جديد

  const CustomTimeButton({
    super.key,
    required this.title,
    required this.selectedTime,
    required this.onTimeSelected,
  });

  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      onPressed: () async {
        // فتح الـ Time Picker
        TimeOfDay? picked = await showTimePicker(
          context: context,
          initialTime: selectedTime,
          builder: (BuildContext context, Widget? child) {
            return Theme(
              data: Theme.of(context).copyWith(
                colorScheme: ColorScheme.light(
                  primary: AppColor.primaryColor, // لون زر التأكيد
                  onPrimary: Colors.white, // لون النص داخل زر التأكيد
                  surface: Colors.white, // خلفية نافذة الاختيار
                  onSurface: AppColor.seconderyColor, // لون النصوص داخل الوقت
                ),
                textButtonTheme: TextButtonThemeData(
                  style: TextButton.styleFrom(
                    foregroundColor: AppColor.primaryColor, // أزرار Cancel/OK
                  ),
                ),
              ),
              child: child!,
            );
          },
        );

        // إذا اختار المستخدم وقت جديد
        if (picked != null) {
          onTimeSelected(picked);
        }
      },
      style: ButtonStyle(
        backgroundColor: WidgetStatePropertyAll(AppColor.seconderyColor),
        shape: WidgetStatePropertyAll(
          RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10.0),
            side: BorderSide(color: AppColor.primaryColor, width: 2.0),
          ),
        ),
      ),
      child: Text(title, style: TextStyle(color: AppColor.textcolor)),
    );
  }
}
