import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:skolar/controller/students/viewstudents_controller.dart';
import 'package:skolar/core/class/handlingdataview.dart';
import 'package:skolar/core/constant/routes.dart';
import 'package:skolar/core/shared/customappbar.dart';
import 'package:skolar/data/model/studentmodel.dart';
import 'package:skolar/view/widget/users/customcardusers.dart';

class Viewstudents extends StatelessWidget {
  const Viewstudents({super.key});

  @override
  Widget build(BuildContext context) {
    Get.put(ViewstudentsController());

    return Scaffold(
      appBar: Customappbar(title: "Student"),
      body: GetBuilder<ViewstudentsController>(
        builder: (controller) => HandlingDataRequest(
          statusRequest: controller.statusRequest,
          widget: Padding(
            padding: const EdgeInsets.all(8.0),
            child: ListView.builder(
              shrinkWrap: true,
              itemCount: controller.data.length,
              itemBuilder: (context, index) {
                final StudentsModel model = controller.data[index];
                return InkWell(
                  onTap: () {
                    print(model.studentId);
                    Get.toNamed(
                      AppRoutes.studentdetails,
                      arguments: {"studentid": model.studentId},
                    );
                  },
                  child: Customcardusers(
                    name: "${model.firstName} ${model.lastName} ",
                    email: model.enrollmentDate!,
                    id: model.studentCode.toString(),
                    number: model.phone!,
                  ),
                );
              },
            ),
          ),
        ),
      ),
    );
  }
}
