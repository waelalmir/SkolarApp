import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:skolar/controller/subjects/viewsubjects_controller.dart';
import 'package:skolar/core/class/handlingdataview.dart';
import 'package:skolar/core/constant/color.dart';
import 'package:skolar/core/constant/routes.dart';
import 'package:skolar/core/shared/customappbar.dart';
import 'package:skolar/data/model/subjectsmodel.dart';

class Viewsubjects extends StatelessWidget {
  const Viewsubjects({super.key});

  @override
  Widget build(BuildContext context) {
    Get.put(ViewsubjectsController());
    return Scaffold(
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Get.toNamed(AppRoutes.addsubjects);
        },
        splashColor: AppColor.thirdColor,
        child: Icon(Icons.add, color: AppColor.white),
      ),
      appBar: Customappbar(title: "Subjects"),
      body: GetBuilder<ViewsubjectsController>(
        builder: (controller) => HandlingDataRequest(
          statusRequest: controller.statusRequest,
          widget: Padding(
            padding: const EdgeInsets.all(8.0),
            child: ListView.builder(
              shrinkWrap: true,
              itemCount: controller.data.length,
              itemBuilder: (context, index) {
                final SubjectsModel model = controller.data[index];
                return Container(
                  margin: EdgeInsets.symmetric(vertical: 10),
                  decoration: BoxDecoration(
                    color: AppColor.thirdColor,
                    borderRadius: BorderRadius.circular(10),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.grey.withOpacity(0.5),
                        spreadRadius: 2,
                        blurRadius: 5,
                        offset: const Offset(0, 3),
                      ),
                    ],
                  ),
                  child: ListTile(
                    title: SelectableText(
                      selectionColor: AppColor.primaryColor,

                      model.name!,
                      style: TextStyle(color: AppColor.white),
                    ),
                    style: ListTileStyle.drawer,
                  ),
                );
              },
            ),
          ),
        ),
      ),
    );
  }
}
