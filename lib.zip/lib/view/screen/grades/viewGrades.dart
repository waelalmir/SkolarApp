import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:skolar/controller/grade/viewgrades_controller.dart';
import 'package:skolar/core/class/handlingdataview.dart';
import 'package:skolar/core/constant/color.dart';
import 'package:skolar/core/functions/responsive.dart';
import 'package:skolar/core/shared/customappbar.dart';
import 'package:skolar/data/model/grade_model.dart';

class ViewGrades extends StatelessWidget {
  const ViewGrades({super.key});

  @override
  Widget build(BuildContext context) {
    Get.put(ViewGradesController());
    final Responsive r = Responsive(context);

    return Scaffold(
      appBar: Customappbar(title: "Grades"),
      body: GetBuilder<ViewGradesController>(
        builder: (controller) {
          return HandlingDataRequest(
            statusRequest: controller.statusRequest,
            widget: Padding(
              padding: EdgeInsetsGeometry.all(10),
              child: ListView.builder(
                itemCount: controller.data.length,
                itemBuilder: (context, index) {
                  final GradeModel model = controller.data[index];
                  controller.currentIndex = index;
                  return Column(
                    children: [
                      Container(
                        margin: EdgeInsets.only(bottom: r.height(12)),
                        decoration: BoxDecoration(
                          color: AppColor.seconderyColor,
                          borderRadius: BorderRadius.circular(r.width(14)),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.15),
                              blurRadius: 8,
                              offset: const Offset(0, 3),
                            ),
                          ],
                        ),
                        child: Theme(
                          data: Theme.of(
                            context,
                          ).copyWith(dividerColor: Colors.transparent),
                          child: ClipRRect(
                            borderRadius: BorderRadiusGeometry.circular(
                              r.width(15),
                            ),
                            child: ExpansionTile(
                              onExpansionChanged: (isExpanded) {
                                if (isExpanded) {
                                  controller.toggle(index, model);
                                }
                              },
                              title: Text(
                                "${model.name}",
                                style: TextStyle(
                                  color: AppColor.textcolor,
                                  fontSize: r.font(20),
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                              backgroundColor: AppColor.seconderyColor,
                              collapsedBackgroundColor: AppColor.thirdColor,
                              collapsedIconColor: AppColor.primaryColor,
                              iconColor: AppColor.primaryColor,
                              children: [
                                if ((controller.gradeSections[model.id] ?? [])
                                    .isEmpty)
                                  Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: Text(
                                      "No sections found",
                                      style: TextStyle(color: AppColor.white),
                                    ),
                                  )
                                else
                                  Padding(
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 10,
                                      vertical: 8,
                                    ),
                                    child: GridView.builder(
                                      shrinkWrap: true,
                                      physics:
                                          const NeverScrollableScrollPhysics(),
                                      itemCount: controller
                                          .gradeSections[model.id]!
                                          .length,
                                      gridDelegate:
                                          SliverGridDelegateWithFixedCrossAxisCount(
                                            crossAxisCount: r
                                                .crossaxisCount(), // كل اثنتين جنب بعض
                                            mainAxisSpacing: 10,
                                            crossAxisSpacing: 10,
                                            childAspectRatio:
                                                1.8, // شكل مستطيل جميل
                                          ),
                                      itemBuilder: (context, sectionIndex) {
                                        final d =
                                            controller.gradeSections[model
                                                .id]![sectionIndex];
                                        return InkWell(
                                          onTap: () {
                                            controller.goToSections(
                                              d.id!,
                                              d,
                                              controller.gradesModel!,
                                              model,
                                            );
                                          },
                                          borderRadius: BorderRadius.circular(
                                            15,
                                          ),
                                          child: Container(
                                            decoration: BoxDecoration(
                                              color: AppColor.primaryColor
                                                  .withOpacity(0.15),
                                              borderRadius:
                                                  BorderRadius.circular(15),
                                              border: Border.all(
                                                color: AppColor.primaryColor
                                                    .withOpacity(0.4),
                                                width: 1,
                                              ),
                                              boxShadow: [
                                                BoxShadow(
                                                  color: Colors.black
                                                      .withOpacity(0.1),
                                                  blurRadius: 6,
                                                  offset: const Offset(2, 3),
                                                ),
                                              ],
                                            ),
                                            padding: const EdgeInsets.all(10),
                                            child: Center(
                                              child: Column(
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                children: [
                                                  Text(
                                                    d.name ?? "",
                                                    style: TextStyle(
                                                      fontWeight:
                                                          FontWeight.bold,
                                                      color: AppColor.white,
                                                      fontSize: r.font(16),
                                                    ),
                                                  ),
                                                  const SizedBox(height: 5),
                                                  Text(
                                                    "Room: ${d.room ?? '-'}",
                                                    style: TextStyle(
                                                      color: AppColor.textcolor
                                                          .withOpacity(0.8),
                                                      fontSize: r.font(13),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                        );
                                      },
                                    ),
                                  ),
                              ],
                            ),
                          ),
                        ),
                      ),

                      // التفاصيل (تظهر فقط إذا كان العنصر مفتوح)
                      // if (controller.openIndex == index)
                      //   Container(
                      //     padding: EdgeInsets.symmetric(
                      //       horizontal: 16,
                      //       vertical: 8,
                      //     ),
                      //     child: controller.loadingDetails
                      //         ? Center(child: CircularProgressIndicator())
                      //         : Column(
                      //             crossAxisAlignment: CrossAxisAlignment.start,
                      //             children: controller.sections.map((d) {
                      //               return InkWell(
                      //                 onTap: () {
                      //                   print("section id ${d.id}");
                      //                   controller.goToSections(
                      //                     d.id!,
                      //                     d,
                      //                     controller.gradesModel!,
                      //                     model,
                      //                   );
                      //                 },
                      //                 child: Padding(
                      //                   padding: const EdgeInsets.symmetric(
                      //                     vertical: 4,
                      //                   ),
                      //                   child: Text("- ${d.name} : ${d.room}"),
                      //                 ),
                      //               );
                      //             }).toList(),
                      //           ),
                      //   ),
                      Divider(),
                    ],
                  );
                },
              ),
            ),
          );
        },
      ),
    );
  }
}
