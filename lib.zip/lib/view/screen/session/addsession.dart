import 'package:drop_down_list/model/selected_list_item.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:skolar/controller/session/addsession_controller.dart';
import 'package:skolar/core/constant/color.dart';
import 'package:skolar/core/shared/customappbar.dart';
import 'package:skolar/core/shared/custombutton.dart';
import 'package:skolar/data/model/grade_model.dart';
import 'package:skolar/data/model/sections_model.dart';
import 'package:skolar/data/model/subjectsmodel.dart';
import 'package:skolar/data/model/teachers_model.dart';
import 'package:skolar/view/widget/session/customtimebutton.dart';
import 'package:skolar/view/widget/student/customgradedropdown.dart';

class Addsession extends StatelessWidget {
  const Addsession({super.key});

  @override
  Widget build(BuildContext context) {
    AddsessionController controller = Get.put(AddsessionController());
    controller.initTimes(
      start: TimeOfDay(hour: 12, minute: 0),
      end: TimeOfDay(hour: 12, minute: 0),
      isNew: true,
    );

    return Scaffold(
      appBar: Customappbar(title: "Add session"),
      body: Padding(
        padding: EdgeInsetsGeometry.all(8),
        child: GetBuilder<AddsessionController>(
          builder: (controller) {
            return Form(
              key: controller.formstate,
              child: ListView(
                children: [
                  /////////////////////////////////////////
                  ///////////////////////////////////////
                  ///////////////////////////////////////
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: AppColor.seconderyColor.withValues(alpha: 0.15),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: AppColor.primaryColor,
                        width: 1.5,
                      ),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        // ✅ خانة وقت البداية
                        Expanded(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(
                                "Start Time",
                                style: TextStyle(
                                  color: AppColor.seconderyColor,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 16,
                                ),
                              ),
                              const SizedBox(height: 8),
                              Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 10,
                                  vertical: 8,
                                ),
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  border: Border.all(
                                    color: AppColor.primaryColor,
                                    width: 1.2,
                                  ),
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: Text(
                                  controller.startTime.format(context),
                                  style: TextStyle(
                                    color: AppColor.primaryColor,
                                    fontSize: 15,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ),
                              const SizedBox(height: 8),
                              CustomTimeButton(
                                title: "Start Time",
                                selectedTime: controller.startTime,
                                onTimeSelected: (picked) {
                                  controller.updateStartTime(picked);
                                },
                              ),
                            ],
                          ),
                        ),

                        const SizedBox(width: 16),

                        // ✅ خانة وقت النهاية
                        Expanded(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(
                                "End Time",
                                style: TextStyle(
                                  color: AppColor.seconderyColor,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 16,
                                ),
                              ),
                              const SizedBox(height: 8),
                              Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 10,
                                  vertical: 8,
                                ),
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  border: Border.all(
                                    color: AppColor.primaryColor,
                                    width: 1.2,
                                  ),
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: Text(
                                  controller.endTime.format(context),
                                  style: TextStyle(
                                    color: AppColor.primaryColor,
                                    fontSize: 15,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ),
                              const SizedBox(height: 8),
                              CustomTimeButton(
                                title: "End time",
                                selectedTime: controller.endTime,
                                onTimeSelected: (picked) {
                                  controller.updateEndTime(picked);
                                },
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  /////////////////////////////////////////
                  ///////////////////////////////////////
                  ///////////////////////////////////////
                  CustomGenericDropDown<SelectedListItem>(
                    title: "Day",
                    listdata: controller.dayesList,
                    dropdownSelectedName: controller.dayNameController,
                    dropdownSelectedID: controller.dayIdController,
                    getItemName: (item) => item.data!,
                    getItemId: (item) => item.data,
                    onSelected: (selectedGrade) {},
                  ),
                  CustomGenericDropDown<GradeModel>(
                    title: "Grades",
                    listdata: controller.gradesList,
                    dropdownSelectedName: controller.gradeNameController,
                    dropdownSelectedID: controller.gradeIdController,
                    getItemName: (item) => item.name!,
                    getItemId: (item) => item.id,
                    onSelected: (selectedGrade) {
                      // عند اختيار صف، نجيب الأقسام التابعة له
                      controller.getSections();
                      controller.getSubjects();
                    },
                  ),

                  CustomGenericDropDown<SubjectsModel>(
                    title: "Subjects",
                    listdata: controller.subjectList,
                    dropdownSelectedName: controller.subjectNameController,
                    dropdownSelectedID: controller.subjectIdController,
                    getItemName: (item) => item.name!,
                    getItemId: (item) => item.id,
                    onSelected: (selectedGrade) {
                      // عند اختيار صف، نجيب الأقسام التابعة له
                      controller.getSubjects();
                    },
                  ),
                  CustomGenericDropDown<TeachersModel>(
                    title: "Teachers",
                    listdata: controller.teachersList,
                    dropdownSelectedName: controller.teacherNameController,
                    dropdownSelectedID: controller.teacherIdController,
                    getItemName: (item) => item.firstName!,
                    getItemId: (item) => item.teacherId,
                    onSelected: (t) {
                      print("selected teacher ${t.original.teacherId}");
                    },
                  ),

                  GetBuilder<AddsessionController>(
                    id: "sectionsDropdown",
                    builder: (controller) {
                      return CustomGenericDropDown<SectionsModel>(
                        title: "Sections",
                        listdata: controller.sectionsList,
                        dropdownSelectedName: controller.sectionNameController,
                        dropdownSelectedID: controller.sectionIdController,
                        getItemName: (item) => item.name!,
                        getItemId: (item) => item.id,
                      );
                    },
                  ),
                  CustomButton(
                    buttontitle: "Add session",
                    onPressedUpload: () {
                      controller.addSession();
                    },
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}
