import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:skolar/controller/session/viewsession_controller.dart';
import 'package:skolar/core/class/handlingdataview.dart';
import 'package:skolar/core/constant/color.dart';
import 'package:skolar/core/functions/responsive.dart';
import 'package:skolar/core/shared/customappbar.dart';
import 'package:skolar/view/screen/session/editsession.dart';
import 'package:skolar/view/widget/session/customsessionbox.dart';

class Viewsession extends StatelessWidget {
  const Viewsession({super.key});

  @override
  Widget build(BuildContext context) {
    Get.put(ViewsessionController());
    final Responsive r = Responsive(context);

    return Scaffold(
      appBar: Customappbar(title: "Weekly Schedule"),
      body: GetBuilder<ViewsessionController>(
        builder: (controller) {
          final days = controller.days;

          return HandlingDataRequest(
            statusRequest: controller.statusRequest,
            widget: Padding(
              padding: EdgeInsets.all(r.padding(8)),
              child: ListView.builder(
                itemCount: days.length,
                itemBuilder: (context, index) {
                  final day = controller.days[index];
                  final sessions = controller.groupedSessions[day]!;
                  return Container(
                    margin: EdgeInsets.only(bottom: r.height(12)),
                    decoration: BoxDecoration(
                      color: AppColor.seconderyColor,
                      borderRadius: BorderRadius.circular(r.width(14)),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.15),
                          blurRadius: 8,
                          offset: const Offset(0, 3),
                        ),
                      ],
                    ),

                    child: Theme(
                      data: Theme.of(
                        context,
                      ).copyWith(dividerColor: Colors.transparent),
                      child: ExpansionTile(
                        tilePadding: EdgeInsets.symmetric(
                          horizontal: r.padding(12),
                          vertical: r.padding(8),
                        ),

                        collapsedIconColor: AppColor.primaryColor,
                        iconColor: AppColor.primaryColor,

                        title: Text(
                          day,
                          style: TextStyle(
                            color: AppColor.textcolor,
                            fontSize: r.font(20),
                            fontWeight: FontWeight.w700,
                          ),
                        ),

                        children: [
                          Padding(
                            padding: EdgeInsets.all(r.padding(12)),
                            child: Column(
                              children: sessions.map((s) {
                                return Container(
                                  padding: EdgeInsets.all(r.padding(12)),
                                  margin: EdgeInsets.only(bottom: r.height(10)),
                                  decoration: BoxDecoration(
                                    color: Colors.black.withOpacity(0.05),
                                    borderRadius: BorderRadius.circular(
                                      r.width(10),
                                    ),
                                  ),
                                  child: Column(
                                    children: [
                                      // زر التعديل
                                      // -------------------------
                                      Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        children: [
                                          IconButton(
                                            onPressed: () {
                                              // ✅ الانتقال لصفحة التعديل
                                              Get.to(
                                                () => Editsession(),
                                                arguments: {"sessionModel": s},
                                              );
                                            },
                                            icon: Icon(
                                              Icons.edit,
                                              color: AppColor.primaryColor,
                                            ),
                                          ),
                                          IconButton(
                                            onPressed: () {
                                              controller.deleteSession(
                                                s.id.toString(),
                                              );
                                            },
                                            icon: Icon(
                                              Icons.delete_outline_rounded,
                                              color: AppColor.primaryColor,
                                            ),
                                          ),
                                        ],
                                      ),

                                      SizedBox(height: r.height(5)),
                                      Row(
                                        children: [
                                          Customsessionbox(
                                            r: r,
                                            title: "Subject",
                                            value: s.subjectName!,
                                          ),
                                          SizedBox(width: r.width(10)),
                                          Customsessionbox(
                                            r: r,
                                            title: "Teacher",
                                            value: s.teacherFullName!,
                                          ),
                                        ],
                                      ),
                                      SizedBox(height: r.height(10)),
                                      Row(
                                        children: [
                                          Customsessionbox(
                                            r: r,
                                            title: "Start",
                                            value: s.startTime ?? "",
                                          ),
                                          SizedBox(width: r.width(10)),
                                          Customsessionbox(
                                            r: r,
                                            title: "End",
                                            value: s.endTime ?? "",
                                          ),
                                        ],
                                      ),
                                      SizedBox(height: r.height(10)),
                                      Row(
                                        children: [
                                          Customsessionbox(
                                            r: r,
                                            title: "Grade",
                                            value: s.gradeName!,
                                          ),
                                          SizedBox(width: r.width(10)),
                                          Customsessionbox(
                                            r: r,
                                            title: "Section",
                                            value: s.sectionName!,
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                );
                              }).toList(),
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          );
        },
      ),
    );
  }
}
