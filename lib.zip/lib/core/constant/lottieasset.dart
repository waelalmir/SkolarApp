class AppLottieAsset {
  static const String rootAsset = "assets/lottie";
  static String lottieerror = "$rootAsset/Error 404.json";
  static String lottieloading = "$rootAsset/loading.json";
  static String lottieoffline = "$rootAsset/No connection.json";
}
