enum StatusRequest {
  loading,
  success,
  failure,
  serverfailure,
  offlinefailure,
  none,
  nodata
}
