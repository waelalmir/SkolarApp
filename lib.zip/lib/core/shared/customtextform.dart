import 'package:skolar/core/constant/color.dart';
import 'package:flutter/material.dart';

class CustomTextForm extends StatelessWidget {
  final String hintText;
  final String labelText;
  final IconData? suffixIcon;
  final TextEditingController? myController;
  final String? Function(String?) valid;
  final bool isNumber;
  final bool? obscureText;
  final bool? isdropdown;
  final void Function()? ontapIcon;
  final void Function()? onTap;

  const CustomTextForm({
    super.key,
    required this.hintText,
    required this.labelText,
    this.suffixIcon,
    required this.myController,
    required this.valid,
    required this.isNumber,
    this.obscureText,
    this.ontapIcon,
    this.onTap,
    this.isdropdown,
  });

  @override
  Widget build(BuildContext context) {
    // تحديد ما إذا كان النص يجب أن يكون مخفياً (كلمة مرور)
    final bool isObscured = obscureText ?? false;

    return Container(
      margin: const EdgeInsets.only(top: 15, bottom: 20),
      child: TextFormField(
        cursorColor: Colors.black,
        readOnly: isdropdown == true ? true : false,
        onTap: onTap,
        // استخدام isObscured لتحديد إخفاء النص
        obscureText: isObscured,
        // تحديد نوع لوحة المفاتيح
        keyboardType: isNumber
            ? const TextInputType.numberWithOptions(decimal: true)
            : TextInputType.text,
        validator: valid,
        controller: myController,
        // تزيين حقل الإدخال
        decoration: InputDecoration(
          border: const OutlineInputBorder(
            borderSide: BorderSide(
              color: Colors.red,
              width: 3,
              style: BorderStyle.solid,
            ),
            borderRadius: BorderRadius.all(Radius.circular(10)),
          ),
          // مظهر مملوء لتبدو أجمل
         

          // أيقونة النهاية القابلة للنقر
          suffixIcon: suffixIcon != null
              ? InkWell(
                  onTap: ontapIcon,
                  child: Icon(suffixIcon, color: Colors.grey[700]),
                )
              : null,

          floatingLabelBehavior: FloatingLabelBehavior.always,

          // تصميم الـ Label
          label: Container(
            margin: const EdgeInsets.symmetric(horizontal: 20),
            child: Text(
              labelText,
              style: const TextStyle(
                fontWeight: FontWeight.bold,
                color: AppColor.primaryColor,
              ),
            ),
          ),

          // حدود موحدة وزوايا دائرية

          // تصميم الحدود عند التركيز
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: const BorderSide(
              color: AppColor.primaryColor,
              width: 2,
            ), // حدود واضحة عند التركيز
          ),

          // تصميم الحدود العادية
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: BorderSide.none,
          ),
        ),
      ),
    );
  }
}
