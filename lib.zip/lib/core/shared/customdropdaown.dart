import 'package:skolar/core/functions/validinput.dart';
import 'package:skolar/core/shared/customtextform.dart';
import 'package:drop_down_list/drop_down_list.dart';
import 'package:drop_down_list/model/selected_list_item.dart';
import 'package:flutter/material.dart';

class CustomDropDown extends StatefulWidget {
  final String title;
  final List<SelectedListItem<dynamic>> listdata;
  final TextEditingController dropdownSelectedName;
  final TextEditingController dropdownSelectedID;

  const CustomDropDown({
    super.key,
    required this.title,
    required this.listdata,
    required this.dropdownSelectedName,
    required this.dropdownSelectedID,
  });

  @override
  State<CustomDropDown> createState() => _CustomDropDownState();
}

class _CustomDropDownState extends State<CustomDropDown> {
  void showDropdown() {
    DropDownState(
      dropDown: DropDown(
        isDismissible: true,
        bottomSheetTitle: Text(
          widget.title,
          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 20.0),
        ),
        submitButtonText: 'Save',
        clearButtonText: 'Clear',
        data: widget.listdata,

        onSelected: (List<dynamic> selectedList) {
          if (selectedList.isNotEmpty) {
            SelectedListItem selectedListItem =
                selectedList.first as SelectedListItem;

            // اسم الدور المختار
            String selectedName = selectedListItem.data.toString();

            widget.dropdownSelectedName.text = selectedName;

            // 🔁 نربط الاسم بالقيمة الحقيقية للـ role
            Map<String, String> roleMap = {
              "Admin": "admin",
              "Principal": "principal",
              "Teacher": "teacher",
              "Student": "student",
              "Parent": "parent",
              "Staff": "staff",
            };

            widget.dropdownSelectedID.text = roleMap[selectedName] ?? "";

            print("=============================");
            print("✅ الدور المختار: ${widget.dropdownSelectedName.text}");
            print(
              "✅ القيمة المرسلة للسيرفر: ${widget.dropdownSelectedID.text}",
            );
          }
        },

        enableMultipleSelection: false, // تم تثبيتها لاختيار عنصر واحد
      ),
    ).showModal(context);
  }

  @override
  Widget build(BuildContext context) {
    return CustomTextForm(
      isdropdown: true,
      hintText: widget.dropdownSelectedName.text.isEmpty
          ? widget.title
          : widget.dropdownSelectedName.text,
      labelText: "Roles",
      myController: widget.dropdownSelectedName,
      valid: (val) {
        return validinput(val!, 0, 100, "");
      },
      isNumber: false,
      onTap: () {
        FocusScope.of(context).unfocus();
        showDropdown();
      },
    );
  }
}
